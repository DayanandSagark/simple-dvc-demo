

def test_config():
    a=2
    b=2
    assert a == b
